package io.higress.api.sdk.demo;

import com.alibaba.fastjson.JSON;
import com.alibaba.higress.sdk.config.HigressServiceConfig;
import com.alibaba.higress.sdk.model.Domain;
import com.alibaba.higress.sdk.model.Route;
import com.alibaba.higress.sdk.model.route.RoutePredicate;
import com.alibaba.higress.sdk.model.route.RoutePredicateTypeEnum;
import com.alibaba.higress.sdk.model.route.UpstreamService;
import com.alibaba.higress.sdk.service.HigressServiceProvider;

import java.nio.file.Paths;
import java.util.Collections;

public class HigressAdminSdkDemoApplication {

    public static void main(String[] args) throws Exception {
        String kubeConfigFile = Paths.get(System.getProperty("user.home"), "/.kube/config").toString();
        HigressServiceConfig config = HigressServiceConfig.builder().withKubeConfigPath(kubeConfigFile).build();
        HigressServiceProvider provider = HigressServiceProvider.create(config);

        Domain domain = Domain.builder()
                .name("www.test.com")
                .enableHttps(Domain.EnableHttps.OFF)
                .build();
        domain = provider.domainService().add(domain);
        System.out.println(JSON.toJSONString(domain, true));

        Route route = Route.builder()
                .name("higress-demo")
                .domains(Collections.singletonList("www.test.com"))
                .path(RoutePredicate.builder()
                        .matchType(RoutePredicateTypeEnum.PRE.name())
                        .matchValue("/")
                        .build())
                .services(Collections.singletonList(
                        UpstreamService.builder()
                                .name("higress-demo-service.default.svc.cluster.local")
                                .port(8080)
                                .build()
                )).build();
        route = provider.routeService().add(route);
        System.out.println(JSON.toJSONString(route, true));
    }
}
